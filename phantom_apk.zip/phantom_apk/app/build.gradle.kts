plugins {
    id("com.android.application")
}

android {
    namespace = "com.phantom.npu"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.phantom.npu"
        minSdk = 35
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    aaptOptions {
        noCompress += "tflite"
    }
}

dependencies {
    // LiteRT 1.x — CompiledModel API hits the Tensor G4 NPU via edgetpu_app_service
    implementation("com.google.ai.edge.litert:litert:1.0.1")
    implementation("com.google.ai.edge.litert:litert-gpu:1.0.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
